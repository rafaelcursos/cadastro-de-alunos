

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row ">

            <div style="border: 1px solid #ddd; padding: 1rem; border-radius: 10px" class="col-md-8 m-auto mt-5 bg-white">
                <h1><u>Pagamento Realizado</u></h1>
                <h3>Aluno: <?php echo e($aluno->nome); ?></h3>
                <span></span>
                <h5>Pagou o valor de <u>R$<?php echo e($valor); ?></u> , dia <?php echo e(date('d/m/Y')); ?>, referente ao(s) curso(s):</h5>
                    <ul>
                        <?php $__currentLoopData = $aluno->cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cursos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <li><?php echo e($cursos->curso); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                <p>RafaelCursos: Av. Raul Alves Ferreira, Nº 35, Centro, Rodeiro, MG.</p>
                <p>(32) 9 9808-3600 </p>
                <button onclick="imprime()" class="btn">Imprimir</button>
            </div>
        </div>
    </div>

    <script>
        function imprime() {
            window.print();
            window.location.href = '/home';
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos-laravel\principais\cadastro-de-alunos\resources\views//aluno/recibo.blade.php ENDPATH**/ ?>