

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6 m-auto">
            <h3>Escolha o horario do seu curso</h3>
            <h5><?php echo e($aluno->nome); ?></h5>
            <form action="/horario_aluno/<?php echo e($aluno->id); ?>" method="post" class="form-group">
                <?php echo csrf_field(); ?>
                <select name="horario" id="horario" class="form-select">
                    <?php $__currentLoopData = $horarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($horario->id); ?>"><?php echo e($horario->horario); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br>
                <input class="btn btn-primary" type="submit" value="Enviar">
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos-laravel\principais\cadastro-de-alunos\resources\views//horario/horario_aluno.blade.php ENDPATH**/ ?>