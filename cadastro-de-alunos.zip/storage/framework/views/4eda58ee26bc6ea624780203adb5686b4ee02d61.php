

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <?php if(session('msg')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('msg')); ?>

                </div>
            <?php endif; ?>
            </div>
        </div>
        <div class="row mb-5">
            <div class="col-12 d-flex justify-content-space-between">

                <div><h1>Todos os cursos</h1></div>
                <div class="m-auto"><a href="/curso/criar" class="btn btn-primary">Novo Curso</a></div>                
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <table class="table table-striped border">
                    <thead>
                        <tr>
                            <th>Curso</th>
                            <th>Descrição</th>
                            <th>Editar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <img width="100" class="img-fluid" src="<?php echo e(Storage::url($curso->imagem)); ?>" alt="<?php echo e($curso->curso); ?>">
                                <p><?php echo e($curso->curso); ?></p>
                            </td>
                            <td><?php echo e($curso->descricao); ?></td>
                            <td>
                                <a href="/curso/ver/<?php echo e($curso->id); ?>" class="btn btn-primary">Editar</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos-laravel\principais\cadastro-de-alunos\resources\views//curso/home.blade.php ENDPATH**/ ?>