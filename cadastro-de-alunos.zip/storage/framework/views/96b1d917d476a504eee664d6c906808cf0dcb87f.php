

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div style="border: 1px solid #ddd; padding: 1rem; border-radius: 10px" class="col-md-6 m-auto mt-5">
            <h1><u>Confirme o Pagamento</u></h1>
            <h3>Aluno: <?php echo e($aluno->nome); ?></h3>
            <form action="/aluno/pagar/<?php echo e($aluno->id); ?>" method="post" class="form-group">
                <?php echo csrf_field(); ?>                
                <label style="font-size: 1rem" for="valor">Valor: R$</label>
                <input style="font-size: 1rem; border:0" type="number" name="valor" id="valor" value="<?php echo e($valor); ?>">
                <button class="btn btn-primary" type="submit">Confirmar</button>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos-laravel\principais\cadastro-de-alunos\resources\views//aluno/pagar.blade.php ENDPATH**/ ?>