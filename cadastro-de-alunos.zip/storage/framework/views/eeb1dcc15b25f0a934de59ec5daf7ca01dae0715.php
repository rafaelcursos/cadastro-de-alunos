

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-6 m-auto">
            <h2>Dia de Vencimento</h2>
            <h5>Aluno: <?php echo e($aluno->nome); ?></h5>

            <form action="/mensalidade/create/<?php echo e($aluno->id); ?>" method="post" class="form-group">
            <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label class="form-label" for="valor">Valor</label>
                    <input type="number" name="valor" id="valor" class="form-control" value="100">
                </div>

                <div class="form-group">
                    <label class="form-label" for="vencimento">vencimento</label>
                    <select class="form-select" name="vencimento" id="vencimento">
                        <option value="10">Dia 10</option>
                        <option value="15">Dia 15</option>
                        <option value="20">Dia 20</option>
                        <option value="25">Dia 25</option>
                    </select>
                </div>
                
                <br>
            <button class="btn btn-primary" type="submit">Enviar</button>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos-laravel\principais\cadastro-de-alunos\resources\views//mensalidade/home.blade.php ENDPATH**/ ?>