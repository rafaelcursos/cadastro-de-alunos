

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6 m-auto">
            <h3>Escolha o dia do seu curso</h3>
            <h5><?php echo e($aluno->nome); ?></h5>
            <form action="/dia_aluno/<?php echo e($aluno->id); ?>" method="post" class="form-group">
                <?php echo csrf_field(); ?>
                <select name="dia" id="dia" class="form-select">
                    <?php $__currentLoopData = $dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($dia->id); ?>"><?php echo e($dia->dia); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br>
                <input class="btn btn-primary" type="submit" value="Enviar">
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos-laravel\principais\cadastro-de-alunos\resources\views//dia/dia_aluno.blade.php ENDPATH**/ ?>