

<?php $__env->startSection('content'); ?>
    <h1>Todos os alunos</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos-laravel\principais\cadastro-de-alunos\resources\views//alunos.blade.php ENDPATH**/ ?>