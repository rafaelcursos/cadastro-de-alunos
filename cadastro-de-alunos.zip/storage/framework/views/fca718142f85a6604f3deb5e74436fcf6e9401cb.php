<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <?php if(session('msg')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('msg')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row mb-5">
            <div class="col-12 d-flex justify-content-space-between">

                <div>
                    <h1>Todos os alunos</h1>
                </div>
                <div class="m-auto"><a href="/aluno/criar" class="btn btn-primary">Novo Aluno</a></div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <table class="table table-striped border">
                    <thead>
                        <tr>
                            <th>Aluno</th>
                            <th>Telefone</th>
                            <th>Ver</th>
                            <th>Pagar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <img width="100" class="img-fluid" src="<?php echo e(Storage::url($aluno->imagem)); ?>"
                                        alt="<?php echo e($aluno->nome); ?>">

                                    <p><?php echo e($aluno->nome); ?></p>
                                </td>
                                <td><?php echo e($aluno->telefone); ?></td>
                                <td>
                                    <a href="/aluno/ver/<?php echo e($aluno->id); ?>" class="btn btn-primary">Ver Aluno</a>
                                </td>
                                <td>
                                    <a href="/aluno/pagar/<?php echo e($aluno->id); ?>" class="btn btn-success">Pagar</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos-laravel\principais\cadastro-de-alunos\resources\views/home.blade.php ENDPATH**/ ?>